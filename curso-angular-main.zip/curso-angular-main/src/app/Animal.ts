export interface Animal {
    nome: string;
    tipo: string;
    idade: number;
}